package com.example.bookservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.bookservice.model.BookDetails;

public interface BookDetailsRepository extends JpaRepository<BookDetails, Long> {
}
