package com.example.bookservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bookservice.model.BookDetails;
import com.example.bookservice.repository.BookDetailsRepository;

@Service
public class BookDetailsService {
	
	@Autowired
    private BookDetailsRepository bookDetailsRepository;

    public List<BookDetails> getAllBooks() {
        return bookDetailsRepository.findAll();
    }

    public BookDetails saveBook(BookDetails bookDetails) {
        return bookDetailsRepository.save(bookDetails);
    }
}
