import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Account, AccountService } from '../account.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent {
  balance:number=0;
  id: number = 1;
  account:Account=new Account;
  constructor(private accountService: AccountService, private rout: ActivatedRoute) { }

  ngOnInit() {
    this.id =1;
    this.accountService.getAccountById(this.id).subscribe(data => {
      this.account = data;
      this.balance=this.account.balance;
    })
  }
  
}
