import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountListComponent } from './account-list/account-list.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { DepositComponent } from './deposit/deposit.component';
import { LoginComponent } from './login/login.component';
import { ProfileComponent } from './profile/profile.component';
import { RegisterComponent } from './register/register.component';
import { RequestCheckbookComponent } from './request-checkbook/request-checkbook.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserComponent } from './user/user.component';
import { WithdrawComponent } from './withdraw/withdraw.component';

const routes: Routes = [
  {path:'', component: LoginComponent},
  {path: 'userlogin', component: UserLoginComponent },
  {path: 'register', component: RegisterComponent },
  {path: 'user', component: UserComponent },
  {path: 'profile', component: ProfileComponent },
  {path: 'checkbook-request', component: RequestCheckbookComponent },
  {path:'accounts', component: AccountListComponent},
  {path:'create-account', component: CreateAccountComponent},
  {path:'deposit/:id', component: DepositComponent},
  {path:'withdraw/:id', component: WithdrawComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
