import { Component } from '@angular/core';

@Component({
  selector: 'app-request-checkbook',
  templateUrl: './request-checkbook.component.html',
  styleUrls: ['./request-checkbook.component.css']
})
export class RequestCheckbookComponent {

}
