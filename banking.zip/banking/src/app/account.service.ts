import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';


export class Account{
  id:number=0;
  accountHolderName:string="";
  balance:number=0;
}

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private httpClient:HttpClient) { }

  private baseUrl="http://localhost:9090/api/accounts"; 

  getAllAccounts():Observable<Account[]>{
    return this.httpClient.get<Account[]>(`${this.baseUrl}`)
  }

  createAccount(account:Account):Observable<Account>{
    return this.httpClient.post<Account>(`${this.baseUrl}`,account)
  }


  getAccountById(id:number):Observable<Account>{
    return this.httpClient.get<Account>(`${this.baseUrl}/${id}`);
  }

  
  deposit(id:number,amount:number):Observable<Account>{
    const requestor={amount}
    return this.httpClient.put<Account>(`${this.baseUrl}/${id}/deposit`,requestor);
  }

  Withdraw(id:number,amount:number):Observable<Account>{
    const requestor={amount}
    return this.httpClient.put<Account>(`${this.baseUrl}/${id}/withdraw`,requestor);
  }











}
